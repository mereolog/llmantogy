SAMPLE_1 = \
"""
There is a four-legged table made of wood. Some time later, a leg of the table is replaced. Even later, the table is demolished so it ceases to exist although the wood is still there after the demolition.
"""

SAMPLE_2 = \
"""
A man is walking when suddenly he starts walking faster and then breaks into a run.
"""

SAMPLE_3 = \
"""
Mr. Potter is the teacher of class 2C at Shapism School and resigns at the beginning of the spring break. After the spring break, Mrs. Bumblebee replaces Mr. Potter as the teacher of 2C. Also, student Mary left the class at the beginning of the break and a new student, John, joins in when the break ends.
"""

SAMPLE_4 = \
"""
A flower is red in the summer. As time passes, the color changes. In autumn the flower is brown.
"""

SAMPLE_5 = \
"""
A man is walking to the station, but before he gets there, he turns around and goes home.
"""

SAMPLE_6 = \
"""
Marriage is a contract between two people that is present in most social and cultural systems and it can change in major (e. g. gender constraints) and minor (e.g. marriage breaking procedures) aspects.
"""